# AIB Fruit Management System

This is a web application for Acer International Bakery to manage their fruit inventory across international locations. The system allows bakery shops to check stock levels, reserve fruits from source cities, borrow from nearby shops, and update inventory levels.

## Features

### For Bakery Shop Staff
- Create an account
- Reserve fruits from source cities
- Borrow fruits from other shops in the same cities
- Check reserve records
- Update fruits stock level in the shop

### For Warehouse Staff
- Create an account
- Update the stock level (check-in)
- Handle total needs by country (approval)
- Arrange delivery to target country central warehouse (checkout)
- Arrange delivery from central warehouse to local bakery shops for different cities (checkout)

### For Senior Management
- Check the analytic consumption report
- User account management
- Update fruits types

## Prerequisites

- Java Development Kit (JDK) 11 or newer
- Apache Maven
- MySQL Server
- Apache Tomcat 10.x or any Jakarta EE 10 compatible application server

## Setup Instructions

### 1. Clone the Repository

```bash
git clone <repository-url>
cd aib-fruits-management
```

### 2. Configure the Database

1. Create a MySQL database:

```bash
mysql -u root -p
```

2. Run the SQL script to create the necessary tables and sample data:

```bash
mysql -u root -p < src/main/resources/database/aib_fruits.sql
```

3. Update the database connection settings in `src/main/java/com/aib/DatabaseConnection.java` if necessary:

```java
private static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
private static final String DB_URL = "jdbc:mysql://localhost:3306/aib_fruits?useSSL=false&serverTimezone=UTC";
private static final String USER = "root";
private static final String PASSWORD = "";
```

### 3. Build the Project

```bash
mvn clean package
```

### 4. Deploy the WAR file

Deploy the generated WAR file (located in the `target` directory) to your application server (e.g., Tomcat).

### 5. Access the Application

Open a web browser and navigate to:

```
http://localhost:8080/Assignment-1.0-SNAPSHOT/
```

## Test User Accounts

Three demo accounts are available for testing:

- Senior Management Role:
  - Username: admin
  - Password: admin123

- Warehouse Staff Role:
  - Username: warehouse
  - Password: warehouse123

- Shop Staff Role:
  - Username: shop
  - Password: shop123

## Project Structure

- `src/main/java/com/aib` - Java source files
- `src/main/webapp` - JSP files and web resources
- `src/main/resources` - Configuration files and database scripts

## Database Schema

The database includes the following main tables:

- `roles` - User roles in the system
- `users` - User accounts
- `countries` - Countries where AIB operates
- `cities` - Cities where AIB has shops and warehouses
- `warehouses` - Warehouse information
- `shops` - Shop information
- `fruits` - Available fruit types
- `warehouse_inventory` - Fruit stock in warehouses
- `shop_inventory` - Fruit stock in shops
- `reservations` - Fruit reservations from shops to warehouses
- `borrows` - Fruit borrowing between shops
- `deliveries` - Delivery records

## Technologies Used

- Java EE 10 (Jakarta EE)
- JSP (JavaServer Pages)
- JSTL (JavaServer Pages Standard Tag Library)
- MySQL Database
- Bootstrap 5 (for responsive layout)
- Font Awesome (for icons) 