-- Create the database
CREATE DATABASE IF NOT EXISTS aib_fruits;
USE aib_fruits;

-- Drop tables if they exist
DROP TABLE IF EXISTS fruit_transactions;
DROP TABLE IF EXISTS shop_inventory;
DROP TABLE IF EXISTS warehouse_inventory;
DROP TABLE IF EXISTS reservations;
DROP TABLE IF EXISTS borrows;
DROP TABLE IF EXISTS deliveries;
DROP TABLE IF EXISTS fruits;
DROP TABLE IF EXISTS cities;
DROP TABLE IF EXISTS countries;
DROP TABLE IF EXISTS shops;
DROP TABLE IF EXISTS warehouses;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS roles;

-- Create roles table
CREATE TABLE roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    description VARCHAR(255)
);

-- Create users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    role_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

-- Create countries table
CREATE TABLE countries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    code VARCHAR(10) NOT NULL
);

-- Create cities table
CREATE TABLE cities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    country_id INT NOT NULL,
    is_source BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (country_id) REFERENCES countries(id)
);

-- Create warehouses table
CREATE TABLE warehouses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    city_id INT NOT NULL,
    is_central BOOLEAN DEFAULT FALSE,
    address VARCHAR(255),
    contact_person VARCHAR(100),
    contact_number VARCHAR(50),
    FOREIGN KEY (city_id) REFERENCES cities(id)
);

-- Create shops table
CREATE TABLE shops (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    city_id INT NOT NULL,
    address VARCHAR(255),
    contact_person VARCHAR(100),
    contact_number VARCHAR(50),
    FOREIGN KEY (city_id) REFERENCES cities(id)
);

-- Create fruits table
CREATE TABLE fruits (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    source_country_id INT,
    unit VARCHAR(20) DEFAULT 'kg',
    image_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (source_country_id) REFERENCES countries(id)
);

-- Create warehouse inventory table
CREATE TABLE warehouse_inventory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    warehouse_id INT NOT NULL,
    fruit_id INT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (warehouse_id) REFERENCES warehouses(id),
    FOREIGN KEY (fruit_id) REFERENCES fruits(id),
    UNIQUE KEY wh_fruit_unique (warehouse_id, fruit_id)
);

-- Create shop inventory table
CREATE TABLE shop_inventory (
    id INT AUTO_INCREMENT PRIMARY KEY,
    shop_id INT NOT NULL,
    fruit_id INT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL DEFAULT 0,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (shop_id) REFERENCES shops(id),
    FOREIGN KEY (fruit_id) REFERENCES fruits(id),
    UNIQUE KEY shop_fruit_unique (shop_id, fruit_id)
);

-- Create reservations table
CREATE TABLE reservations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    shop_id INT NOT NULL,
    source_warehouse_id INT NOT NULL,
    fruit_id INT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'approved', 'rejected', 'delivered') DEFAULT 'pending',
    requested_by INT NOT NULL,
    approved_by INT,
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_at TIMESTAMP NULL,
    delivery_date DATE,
    notes TEXT,
    FOREIGN KEY (shop_id) REFERENCES shops(id),
    FOREIGN KEY (source_warehouse_id) REFERENCES warehouses(id),
    FOREIGN KEY (fruit_id) REFERENCES fruits(id),
    FOREIGN KEY (requested_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id)
);

-- Create borrows table
CREATE TABLE borrows (
    id INT AUTO_INCREMENT PRIMARY KEY,
    requesting_shop_id INT NOT NULL,
    lending_shop_id INT NOT NULL,
    fruit_id INT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'approved', 'rejected', 'returned') DEFAULT 'pending',
    requested_by INT NOT NULL,
    approved_by INT,
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_at TIMESTAMP NULL,
    return_date DATE,
    returned_at TIMESTAMP NULL,
    notes TEXT,
    FOREIGN KEY (requesting_shop_id) REFERENCES shops(id),
    FOREIGN KEY (lending_shop_id) REFERENCES shops(id),
    FOREIGN KEY (fruit_id) REFERENCES fruits(id),
    FOREIGN KEY (requested_by) REFERENCES users(id),
    FOREIGN KEY (approved_by) REFERENCES users(id)
);

-- Create deliveries table
CREATE TABLE deliveries (
    id INT AUTO_INCREMENT PRIMARY KEY,
    from_warehouse_id INT NOT NULL,
    to_warehouse_id INT,
    to_shop_id INT,
    fruit_id INT NOT NULL,
    quantity DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'in_transit', 'delivered', 'cancelled') DEFAULT 'pending',
    created_by INT NOT NULL,
    reservation_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    shipped_at TIMESTAMP NULL,
    delivered_at TIMESTAMP NULL,
    tracking_number VARCHAR(100),
    notes TEXT,
    FOREIGN KEY (from_warehouse_id) REFERENCES warehouses(id),
    FOREIGN KEY (to_warehouse_id) REFERENCES warehouses(id),
    FOREIGN KEY (to_shop_id) REFERENCES shops(id),
    FOREIGN KEY (fruit_id) REFERENCES fruits(id),
    FOREIGN KEY (created_by) REFERENCES users(id),
    FOREIGN KEY (reservation_id) REFERENCES reservations(id)
);

-- Create fruit_transactions table for tracking all movements
CREATE TABLE fruit_transactions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    fruit_id INT NOT NULL,
    transaction_type ENUM('purchase', 'reservation', 'borrow', 'delivery', 'inventory_adjustment') NOT NULL,
    from_warehouse_id INT,
    from_shop_id INT,
    to_warehouse_id INT,
    to_shop_id INT,
    quantity DECIMAL(10,2) NOT NULL,
    transaction_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    reference_id INT COMMENT 'ID from the respective transaction table',
    created_by INT NOT NULL,
    notes TEXT,
    FOREIGN KEY (fruit_id) REFERENCES fruits(id),
    FOREIGN KEY (from_warehouse_id) REFERENCES warehouses(id),
    FOREIGN KEY (from_shop_id) REFERENCES shops(id),
    FOREIGN KEY (to_warehouse_id) REFERENCES warehouses(id),
    FOREIGN KEY (to_shop_id) REFERENCES shops(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
);

-- Insert default roles
INSERT INTO roles (name, description) VALUES 
('Senior Management', 'Senior management with access to analytics and user management'),
('Warehouse Staff', 'Staff managing warehouse operations and deliveries'),
('Shop Staff', 'Staff managing bakery shop operations and inventory');

-- Insert sample countries
INSERT INTO countries (name, code) VALUES 
('Japan', 'JP'),
('United States', 'US'),
('Hong Kong', 'HK');

-- Insert sample cities
INSERT INTO cities (name, country_id, is_source) VALUES 
('Tokyo', 1, TRUE),
('Osaka', 1, FALSE),
('New York', 2, TRUE),
('Los Angeles', 2, FALSE),
('Hong Kong Central', 3, TRUE);

-- Insert sample warehouses
INSERT INTO warehouses (name, city_id, is_central, address, contact_person, contact_number) VALUES 
('Tokyo Central Warehouse', 1, TRUE, '1-1 Chiyoda, Tokyo', 'Kenji Tanaka', '+81-3-1234-5678'),
('Osaka Warehouse', 2, FALSE, '2-3 Chuo, Osaka', 'Yuki Sato', '+81-6-1234-5678'),
('New York Central Warehouse', 3, TRUE, '123 Broadway, New York', 'John Smith', '+1-212-555-1234'),
('LA Warehouse', 4, FALSE, '456 Hollywood Blvd, Los Angeles', 'Emily Davis', '+1-323-555-6789'),
('Hong Kong Central Warehouse', 5, TRUE, '789 Nathan Road, Kowloon', 'Jackie Chan', '+852-1234-5678');

-- Insert sample shops
INSERT INTO shops (name, city_id, address, contact_person, contact_number) VALUES 
('Tokyo Bakery', 1, '10-1 Ginza, Tokyo', 'Akira Suzuki', '+81-3-9876-5432'),
('Osaka Bakery', 2, '5-7 Namba, Osaka', 'Haruka Takahashi', '+81-6-9876-5432'),
('New York Bakery', 3, '345 Fifth Avenue, New York', 'Jennifer Wilson', '+1-212-555-9876'),
('LA Bakery', 4, '789 Sunset Blvd, Los Angeles', 'Michael Johnson', '+1-323-555-4321'),
('Hong Kong Bakery', 5, '123 Central District, Hong Kong', 'Lucy Wong', '+852-9876-5432');

-- Insert sample fruits
INSERT INTO fruits (name, description, source_country_id, unit, image_url) VALUES 
('Apple', 'Fresh red apples from Japan', 1, 'kg', 'apple.jpg'),
('Orange', 'Sweet oranges from California', 2, 'kg', 'orange.jpg'),
('Banana', 'Yellow bananas from various sources', 1, 'kg', 'banana.jpg'),
('Strawberry', 'Sweet strawberries', 2, 'kg', 'strawberry.jpg'),
('Mango', 'Tropical mangoes', 3, 'kg', 'mango.jpg'),
('Blueberry', 'Fresh blueberries', 2, 'kg', 'blueberry.jpg'),
('Kiwi', 'Green kiwi fruit', 1, 'kg', 'kiwi.jpg'),
('Pineapple', 'Tropical pineapples', 3, 'kg', 'pineapple.jpg');

-- Insert sample warehouse inventory
INSERT INTO warehouse_inventory (warehouse_id, fruit_id, quantity) VALUES 
(1, 1, 500), (1, 3, 300), (1, 7, 200),
(2, 1, 200), (2, 3, 150), (2, 7, 100),
(3, 2, 450), (3, 4, 250), (3, 6, 300),
(4, 2, 200), (4, 4, 100), (4, 6, 150),
(5, 5, 400), (5, 8, 350);

-- Insert sample shop inventory
INSERT INTO shop_inventory (shop_id, fruit_id, quantity) VALUES 
(1, 1, 50), (1, 3, 30), (1, 7, 20),
(2, 1, 40), (2, 3, 25), (2, 7, 15),
(3, 2, 45), (3, 4, 30), (3, 6, 35),
(4, 2, 35), (4, 4, 20), (4, 6, 25),
(5, 5, 40), (5, 8, 35);

-- Insert demo user accounts
INSERT INTO users (username, password, full_name, email, role_id) VALUES
('admin', 'admin123', 'Admin User', 'admin@aib-fruits.com', 1),
('warehouse', 'warehouse123', 'Warehouse Manager', 'warehouse@aib-fruits.com', 2),
('shop', 'shop123', 'Shop Manager', 'shop@aib-fruits.com', 3);

-- Sample reservation
INSERT INTO reservations (shop_id, source_warehouse_id, fruit_id, quantity, requested_by) VALUES
(1, 1, 1, 25, 3);

-- Sample borrow
INSERT INTO borrows (requesting_shop_id, lending_shop_id, fruit_id, quantity, requested_by) VALUES
(2, 1, 1, 10, 3);

-- Sample delivery
INSERT INTO deliveries (from_warehouse_id, to_shop_id, fruit_id, quantity, created_by) VALUES
(1, 1, 1, 25, 2); 