package com.aib;

import org.mindrot.jbcrypt.BCrypt;

/**
 * Utility class for security-related operations like password hashing and verification
 */
public class SecurityUtil {
    
    /**
     * Hash a password using BCrypt
     * @param plainTextPassword The password to hash
     * @return The hashed password
     */
    public static String hashPassword(String plainTextPassword) {
        return BCrypt.hashpw(plainTextPassword, BCrypt.gensalt(12));
    }
    
    /**
     * Verify a password against a hashed password
     * @param plainTextPassword The plain text password to check
     * @param hashedPassword The hashed password to check against
     * @return true if the password matches, false otherwise
     */
    public static boolean verifyPassword(String plainTextPassword, String hashedPassword) {
        try {
            return BCrypt.checkpw(plainTextPassword, hashedPassword);
        } catch (IllegalArgumentException e) {
            // This happens if the stored hash is not in the correct format
            // This is a common scenario when transitioning to BCrypt from plain text
            return false;
        }
    }
    
    /**
     * Check if a password is hashed with BCrypt
     * @param password The password to check
     * @return true if the password is hashed with BCrypt, false otherwise
     */
    public static boolean isPasswordHashed(String password) {
        return password != null && password.startsWith("$2a$");
    }
} 