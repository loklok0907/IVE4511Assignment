package com.aib;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet that handles forwarding to JSP pages to avoid 404 errors
 */
public class ForwardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        handleRequest(request, response);
    }
    
    private void handleRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String path = request.getParameter("path");
        
        if (path == null || path.isEmpty()) {
            // Default to profile.jsp if no path is specified
            path = "/profile.jsp";
        }
        
        // Ensure path starts with a slash
        if (!path.startsWith("/")) {
            path = "/" + path;
        }
        
        // Forward to the specified path
        request.getRequestDispatcher(path).forward(request, response);
    }
} 