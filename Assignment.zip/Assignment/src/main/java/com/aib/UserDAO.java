package com.aib;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    /**
     * Authenticate a user with the given username and password
     * @param username The username to authenticate
     * @param password The password to authenticate
     * @return A User object if authentication is successful, null otherwise
     */
    public static User authenticateUser(String username, String password) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseConnection.getConnection();
            
            String sql = "SELECT u.id, u.username, u.full_name, u.email, r.name as role_name, u.role_id, u.password " +
                         "FROM users u " +
                         "JOIN roles r ON u.role_id = r.id " +
                         "WHERE u.username = ?";
            
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                String hashedPassword = rs.getString("password");
                
                // Check if the password needs to be hashed (transitioning from plain text)
                if (!SecurityUtil.isPasswordHashed(hashedPassword)) {
                    if (password.equals(hashedPassword)) {
                        // Upgrade the password to BCrypt hash
                        String newHashedPassword = SecurityUtil.hashPassword(password);
                        updateUserPassword(rs.getInt("id"), newHashedPassword);
                        
                        // Return the user object
                        return new User(
                            rs.getInt("id"),
                            rs.getString("username"),
                            rs.getString("full_name"),
                            rs.getString("email"),
                            rs.getString("role_name"),
                            rs.getInt("role_id")
                        );
                    }
                } else if (SecurityUtil.verifyPassword(password, hashedPassword)) {
                    // Password is hashed and matches
                    return new User(
                        rs.getInt("id"),
                        rs.getString("username"),
                        rs.getString("full_name"),
                        rs.getString("email"),
                        rs.getString("role_name"),
                        rs.getInt("role_id")
                    );
                }
            }
            
            return null;  // Authentication failed
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Register a new user
     * @param username The username for the new user
     * @param password The password for the new user
     * @param fullName The full name of the new user
     * @param email The email address of the new user
     * @param roleId The role ID for the new user
     * @return The ID of the newly registered user, or -1 if registration failed
     */
    public static int registerUser(String username, String password, String fullName, String email, int roleId) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet generatedKeys = null;
        
        try {
            conn = DatabaseConnection.getConnection();
            
            String sql = "INSERT INTO users (username, password, full_name, email, role_id) VALUES (?, ?, ?, ?, ?)";
            
            // Hash the password before storing
            String hashedPassword = SecurityUtil.hashPassword(password);
            
            stmt = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stmt.setString(1, username);
            stmt.setString(2, hashedPassword);
            stmt.setString(3, fullName);
            stmt.setString(4, email);
            stmt.setInt(5, roleId);
            
            int affectedRows = stmt.executeUpdate();
            
            if (affectedRows == 0) {
                return -1;  // Failed to insert
            }
            
            generatedKeys = stmt.getGeneratedKeys();
            if (generatedKeys.next()) {
                return generatedKeys.getInt(1);
            } else {
                return -1;  // Failed to get generated keys
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return -1;
        } finally {
            try {
                if (generatedKeys != null) generatedKeys.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Check if a username already exists in the database
     * @param username The username to check
     * @return true if the username exists, false otherwise
     */
    public static boolean usernameExists(String username) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseConnection.getConnection();
            
            String sql = "SELECT COUNT(*) FROM users WHERE username = ?";
            
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
            return false;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Get all roles from the database
     * @return A list of roles
     */
    public static List<Role> getAllRoles() throws SQLException {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        List<Role> roles = new ArrayList<>();
        
        try {
            conn = DatabaseConnection.getConnection();
            
            String sql = "SELECT id, name, description FROM roles";
            
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                roles.add(new Role(
                    rs.getInt("id"),
                    rs.getString("name"),
                    rs.getString("description")
                ));
            }
            
            return roles;
        } finally {
            if (rs != null) rs.close();
            if (stmt != null) stmt.close();
            if (conn != null) conn.close();
        }
    }
    
    /**
     * Update a user's profile information
     * @param userId The ID of the user to update
     * @param fullName The new full name
     * @param email The new email address
     * @return true if the update was successful, false otherwise
     */
    public static boolean updateUserProfile(int userId, String fullName, String email) {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DatabaseConnection.getConnection();
            
            String sql = "UPDATE users SET full_name = ?, email = ? WHERE id = ?";
            
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, fullName);
            stmt.setString(2, email);
            stmt.setInt(3, userId);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Change a user's password
     * @param userId The ID of the user
     * @param currentPassword The current password for verification
     * @param newPassword The new password to set
     * @return true if the password was changed successfully, false otherwise
     */
    public static boolean changeUserPassword(int userId, String currentPassword, String newPassword) {
        Connection conn = null;
        PreparedStatement getStmt = null;
        PreparedStatement updateStmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseConnection.getConnection();
            conn.setAutoCommit(false);
            
            // First, verify the current password
            String getSql = "SELECT password FROM users WHERE id = ?";
            getStmt = conn.prepareStatement(getSql);
            getStmt.setInt(1, userId);
            
            rs = getStmt.executeQuery();
            
            if (!rs.next()) {
                // User not found
                return false;
            }
            
            String storedPassword = rs.getString("password");
            boolean passwordVerified = false;
            
            // Check if the password is hashed
            if (SecurityUtil.isPasswordHashed(storedPassword)) {
                passwordVerified = SecurityUtil.verifyPassword(currentPassword, storedPassword);
            } else {
                // Plain text comparison for legacy passwords
                passwordVerified = currentPassword.equals(storedPassword);
            }
            
            if (!passwordVerified) {
                // Current password is incorrect
                return false;
            }
            
            // Update the password with a hashed version
            String updateSql = "UPDATE users SET password = ? WHERE id = ?";
            updateStmt = conn.prepareStatement(updateSql);
            updateStmt.setString(1, SecurityUtil.hashPassword(newPassword));
            updateStmt.setInt(2, userId);
            
            int affectedRows = updateStmt.executeUpdate();
            
            conn.commit();
            return affectedRows > 0;
        } catch (SQLException e) {
            try {
                if (conn != null) conn.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (rs != null) rs.close();
                if (getStmt != null) getStmt.close();
                if (updateStmt != null) updateStmt.close();
                if (conn != null) {
                    conn.setAutoCommit(true);
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Update a user's password directly
     * @param userId The ID of the user
     * @param hashedPassword The already hashed password
     * @return true if the update was successful, false otherwise
     */
    private static boolean updateUserPassword(int userId, String hashedPassword) {
        Connection conn = null;
        PreparedStatement stmt = null;
        
        try {
            conn = DatabaseConnection.getConnection();
            
            String sql = "UPDATE users SET password = ? WHERE id = ?";
            
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, hashedPassword);
            stmt.setInt(2, userId);
            
            int affectedRows = stmt.executeUpdate();
            return affectedRows > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Get a user by username
     * @param username The username to look up
     * @return A User object if found, null otherwise
     */
    public static User getUserByUsername(String username) {
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        
        try {
            conn = DatabaseConnection.getConnection();
            
            String sql = "SELECT u.id, u.username, u.full_name, u.email, r.name as role_name, u.role_id " +
                         "FROM users u " +
                         "JOIN roles r ON u.role_id = r.id " +
                         "WHERE u.username = ?";
            
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            
            rs = stmt.executeQuery();
            
            if (rs.next()) {
                return new User(
                    rs.getInt("id"),
                    rs.getString("username"),
                    rs.getString("full_name"),
                    rs.getString("email"),
                    rs.getString("role_name"),
                    rs.getInt("role_id")
                );
            }
            
            return null;  // User not found
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        } finally {
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
} 