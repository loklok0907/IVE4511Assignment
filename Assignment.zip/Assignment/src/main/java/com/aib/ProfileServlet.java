package com.aib;

import java.io.IOException;
import java.net.URLEncoder;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class ProfileServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        
        // Check if user is logged in
        if (user == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        String action = request.getParameter("action");
        
        if ("updateProfile".equals(action)) {
            // Handle profile update
            String fullName = request.getParameter("fullName");
            String email = request.getParameter("email");
            
            // Validate input
            if (fullName == null || fullName.trim().isEmpty() || 
                email == null || email.trim().isEmpty()) {
                
                session.setAttribute("errorMessage", "Full name and email are required");
                response.sendRedirect(request.getContextPath() + "/profile.jsp");
                return;
            }
            
            // Update user profile
            boolean updateSuccess = UserDAO.updateUserProfile(user.getId(), fullName, email);
            
            if (updateSuccess) {
                // Update the user object in the session
                user.setFullName(fullName);
                user.setEmail(email);
                session.setAttribute("user", user);
                
                // Redirect to success page with appropriate message
                String successMessage = "Profile updated successfully!";
                String encodedMessage = URLEncoder.encode(successMessage, "UTF-8");
                response.sendRedirect(request.getContextPath() + "/success.jsp?message=" + encodedMessage);
                return;
            } else {
                session.setAttribute("errorMessage", "Failed to update profile. Please try again.");
                response.sendRedirect(request.getContextPath() + "/profile.jsp");
            }
            
        } else if ("changePassword".equals(action)) {
            // Handle password change
            String currentPassword = request.getParameter("currentPassword");
            String newPassword = request.getParameter("newPassword");
            String confirmPassword = request.getParameter("confirmPassword");
            
            // Validate input
            if (currentPassword == null || currentPassword.trim().isEmpty() ||
                newPassword == null || newPassword.trim().isEmpty() ||
                confirmPassword == null || confirmPassword.trim().isEmpty()) {
                
                session.setAttribute("errorMessage", "All password fields are required");
                response.sendRedirect(request.getContextPath() + "/profile.jsp");
                return;
            }
            
            if (newPassword.length() < 8) {
                session.setAttribute("errorMessage", "Password must be at least 8 characters long");
                response.sendRedirect(request.getContextPath() + "/profile.jsp");
                return;
            }
            
            if (!newPassword.equals(confirmPassword)) {
                session.setAttribute("errorMessage", "New passwords do not match");
                response.sendRedirect(request.getContextPath() + "/profile.jsp");
                return;
            }
            
            // Change password
            boolean passwordChanged = UserDAO.changeUserPassword(user.getId(), currentPassword, newPassword);
            
            if (passwordChanged) {
                // Set a success message to display on the profile page
                String successMessage = "Password changed successfully!";
                String encodedMessage = URLEncoder.encode(successMessage, "UTF-8");
                response.sendRedirect(request.getContextPath() + "/success.jsp?message=" + encodedMessage);
                return;
            } else {
                session.setAttribute("errorMessage", "Failed to change password. Please check your current password and try again.");
                response.sendRedirect(request.getContextPath() + "/profile.jsp");
            }
        } else {
            // Redirect back to profile page for any other action
            response.sendRedirect(request.getContextPath() + "/profile.jsp");
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // For GET requests, just forward to the profile.jsp page
        request.getRequestDispatcher("/profile.jsp").forward(request, response);
    }
} 