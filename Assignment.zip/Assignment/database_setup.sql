-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS aib_fruits;

-- Use the database
USE aib_fruits;

-- Create the roles table
CREATE TABLE IF NOT EXISTS roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255)
);

-- Create the users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    role_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id)
);

-- Insert default roles
INSERT INTO roles (name, description) 
VALUES 
('admin', 'Administrator with full access'),
('manager', 'Manages inventory and operations'),
('user', 'Regular user with limited access')
ON DUPLICATE KEY UPDATE description = VALUES(description);

-- Insert default admin user (password: admin123)
-- Note: In a production environment, use a proper password hashing mechanism
INSERT INTO users (username, password, full_name, email, role_id)
VALUES 
('admin', '$2a$10$QZ8RhyOH.yrX1EYUlTwQQuH1FIxozkEEfm10S/Zx1NXi/ZIrMFDkK', 'System Administrator', 'admin@example.com', 1)
ON DUPLICATE KEY UPDATE password = VALUES(password);

-- Insert test user (password: password123)
INSERT INTO users (username, password, full_name, email, role_id)
VALUES 
('user', '$2a$10$ySG8AQIu7jKJ1/nYZoEcLuE.aM9wV.htlPHXUXsSNwojiTteXtQZG', 'Test User', 'user@example.com', 3)
ON DUPLICATE KEY UPDATE password = VALUES(password); 